# Why the Program Stops Before Achieving Target

This document explains all possible reasons why the LeetCode Automater program stops before reaching the target number of successful submissions.

## 🔴 Main Stopping Conditions

### 1. **No Available Questions Found** ⚠️ (MOST COMMON)

**Problem:** The program randomly selects questions, but if too many are excluded, it may fail to find valid questions.

**How it happens:**
- `getRandomQuestion()` tries to find a question that's NOT in the exclude set
- Originally, it only tried **4 times** (`MAX_RANDOM_ATTEMPTS = 4`)
- If all 4 random attempts hit excluded questions, it returns `null` and the loop breaks

**What gets excluded:**
- **Premium questions** (~800+ questions)
- **Database-only questions** (~200+ questions)  
- **Already solved questions** (from your LeetCode account)
- **Successfully submitted questions** (from `progress.json`)

**Example:** If you've solved 500 questions and successfully submitted 600 more, plus ~1000 premium/DB questions are excluded, you might only have ~1500 available questions out of 3691. With only 4 random attempts, there's a high chance of failure.

**✅ Fix Applied:** Increased random attempts to at least 100 times before giving up.

---

### 2. **Cloudflare Blocking** 🚫

**Problem:** LeetCode's Cloudflare protection detects automated activity and blocks requests.

**How it happens:**
- After **4 Cloudflare rejections** (status 403/429), the program stops
- Check your `skipped.log` for entries like "blocked (status 429)"

**Solutions:**
- Increase delays between attempts (`DELAY_BETWEEN_ATTEMPTS_MS`)
- Wait longer before retrying after a block
- Reduce request frequency

**Current settings:**
- `DELAY_BETWEEN_ATTEMPTS_MS: 5000` (5 seconds)
- `ADDITIONAL_DELAY_MS: 2000` (random 0-2 seconds)
- Rate limit backoff with exponential increase

---

### 3. **Overall Attempt Limit Reached** 📊

**Problem:** The program has a hard limit on total attempts (successful or not).

**How it happens:**
- `OVERALL_ATTEMPT_LIMIT = 2000` (default)
- After 2000 total attempts, the program stops
- This includes ALL attempts: successes, failures, skips, blocks

**Example:** If you need 100 successes but have a 10% success rate, you might need 1000+ attempts. If many questions are skipped (no code found, premium, etc.), you could hit 2000 attempts before reaching the target.

**Solution:** Increase `OVERALL_ATTEMPT_LIMIT` in the CONFIG if you need more attempts.

---

### 4. **Failed to Fetch Solved Questions** ❌

**Problem:** If the program can't retrieve your solved questions from LeetCode, it exits early.

**How it happens:**
- `fetchSolvedQuestions()` makes GraphQL requests to LeetCode
- If it fails or returns empty, the program exits with error: "Failed to retrieve solved questions"

**Possible causes:**
- Network issues
- Invalid session token
- LeetCode API changes
- Rate limiting on the GraphQL endpoint

---

### 5. **Rate Limiting Exhaustion** ⏱️

**Problem:** After multiple rate limit retries, requests may permanently fail.

**How it happens:**
- Each request has `RATE_LIMIT_MAX_RETRIES = 5` attempts
- If all retries are exhausted, the request fails
- Multiple failed requests can effectively stop progress

**Current backoff strategy:**
- Initial backoff: 15 seconds
- Multiplier: 2x
- Max backoff: 300 seconds (5 minutes)

---

## 📈 How to Diagnose

### Check the Summary Output

When the program stops, it shows a summary with:
- Successes vs Target
- Total attempts
- Cloudflare rejections
- Available questions count

### Check `progress.json`

Shows which questions were successfully submitted (`true`) or failed (`false`).

### Check `skipped.log`

Shows why questions were skipped:
- "LeetCode URL not found" - Question not in merged_output.json
- "No code found" - walkcc_url didn't return code
- "blocked (status 429)" - Rate limited
- "premium" - Premium question

---

## 🔧 Improvements Made

1. **Increased Random Attempts:** Changed from 4 to at least 100 attempts before giving up
2. **Better Error Messages:** Now shows detailed breakdown when no questions are available
3. **Enhanced Summary:** Shows available questions count and specific stopping reason
4. **Diagnostic Info:** Displays exclude set breakdown (premium, DB, solved, submitted counts)

---

## 💡 Recommendations

1. **Monitor Available Questions:** If available questions drop below 100, consider:
   - Clearing `progress.json` for failed attempts (keep only successes)
   - Manually excluding fewer questions
   - Increasing `MAX_Q` if new questions are added

2. **Handle Cloudflare Better:**
   - Increase delays if you see frequent 429 errors
   - Consider running during off-peak hours
   - Spread attempts over multiple sessions

3. **Adjust Limits:**
   - If you need more attempts, increase `OVERALL_ATTEMPT_LIMIT`
   - If success rate is low, you may need more attempts to reach target

4. **Check Data Quality:**
   - Ensure `merged_output.json` has complete data
   - Many "No code found" entries suggest data issues

---

## 📊 Example Scenarios

### Scenario 1: High Exclusion Rate
- Solved: 500 questions
- Successfully submitted: 600 questions  
- Premium/DB: 1000 questions
- **Available:** ~1500/3691 (40%)
- **Risk:** Medium - should still find questions with 100 attempts

### Scenario 2: Cloudflare Blocking
- Multiple 429 errors in `skipped.log`
- Program stops after 4 blocks
- **Solution:** Increase delays, wait before retrying

### Scenario 3: Low Success Rate
- Target: 100 successes
- Success rate: 5%
- Need: ~2000 attempts
- **Risk:** May hit `OVERALL_ATTEMPT_LIMIT` before target
- **Solution:** Increase limit or improve success rate

---

## 🎯 Quick Fixes

1. **Increase attempt limit:**
   ```javascript
   OVERALL_ATTEMPT_LIMIT: 5000  // Instead of 2000
   ```

2. **Increase delays:**
   ```javascript
   DELAY_BETWEEN_ATTEMPTS_MS: 10000  // 10 seconds instead of 5
   ```

3. **Clear failed progress (keep only successes):**
   - Edit `progress.json` to remove `false` entries
   - This reduces exclude set size

4. **Check data completeness:**
   - Verify `merged_output.json` has entries for questions 1-3691
   - Check if `walkcc_url` entries are valid

